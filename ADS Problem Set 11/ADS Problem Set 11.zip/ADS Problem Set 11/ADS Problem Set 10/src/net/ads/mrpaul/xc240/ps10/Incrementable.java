package net.mrpaul.ads.xc240.ps10;

public interface Incrementable {
	public void increment();
	public int getValue();
}
