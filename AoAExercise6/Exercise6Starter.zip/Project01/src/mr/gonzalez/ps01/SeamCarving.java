package mr.gonzalez.ps01;
import images.APImage;
public class SeamCarving {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
	}

}
