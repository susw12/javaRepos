/**            <-----------note the extra star
 *All about me!
 *Prints out information all about me!
 *<p>
 *Accel PS00: Print, Baby, Print!
 *Date: 2/7/2018
 *
 *@author Sujay Swain
 */

package net.mrpaul.ads.xc170.ps00;

public class About {
    /**
     * <p>Information about me</p>
     */
    public static void main(String[] args){
        System.out.println("Hello Mr. Gonzalez and Mr. Paul");
        System.out.print("My name is Sujay Swain.\nI am 14 years old.\n");
        System.out.println("Outside of school I go to hackathons.\nI also play the tabla and learn Sanskrit");
    }//end main()
}//end About